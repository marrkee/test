
-- 1. What user posted the most messages in room 1 (room whose id is 1), and how many did he sent?
--     - Your query should return a table with columns (`user_id`, `count`)
--     - Your query should return at most 1 row.

SELECT user_id, 
       Count(*) 
FROM   messages 
WHERE  room_id = 1 
GROUP  BY user_id 
ORDER  BY count DESC 
LIMIT  1; 


-- 2. In what room the user 1 (user whose id is 1) has sent the most messages, and how many messages did he sent in this room?
--     - Your query should return a table with columns (`room_id`, `room_name`, `count`)
--     - Your query should return at most 1 row

SELECT room_id, 
       r.name, 
       Count(*) 
FROM   messages m 
       LEFT JOIN rooms r 
              ON r.owner = m.room_id 
WHERE  user_id = 1 
GROUP  BY room_id, 
          r.name 
ORDER  BY count DESC 
LIMIT  1; 

-- 3. Is there any message quoting a message which has been posted in a different room?
--     - Your query should return a table with columns (`message_id`, `message_room_name`, `quoted_message_id`, `quoted_message_room_name`)
--     - Results should be sorted by descending message_id

SELECT m1.id, 
       m1.room_id, 
       m1.quoted_message_id, 
       m2.room_id 
FROM   messages m1 
       LEFT JOIN messages m2 
              ON m1.quoted_message_id = m2.id 
WHERE  m1.room_id <> m2.room_id 
ORDER  BY m1.id DESC; 

-- 4. For each user, display the number of different ips he used
--     - Ips should be retrieved from the `users` and `messages` tables
--     - Your query should return a table with columns (`user_id`, `count`)
--     - Results should be sorted by ascending user_id

SELECT user_id, 
       Count(*) 
FROM   (SELECT user_id, 
               ip 
        FROM   messages 
        UNION 
        SELECT id, 
               ip 
        FROM   users) data 
GROUP  BY user_id 
ORDER  BY user_id ASC; 


-- 5. How long is the quote chain for message 7 (message whose id is 7)?
--     - Example: If message C quotes message B which itself quotes message A, and we consider message C, then there is a quote chain from message A to message B and the length of the quote chain is 2 (= number of embedded quotes).
--     - Your query should return a table with a single column named `count`
--     - Your query should return at most 1 row

WITH recursive quoted AS 
( 
       SELECT id, 
              quoted_message_id 
       FROM   messages 
       WHERE  id = 7 
       AND    quoted_message_id <> 0 
       UNION 
       SELECT     e.id, 
                  e.quoted_message_id 
       FROM       messages e 
       INNER JOIN quoted q 
       ON         q.quoted_message_id = e.id 
       WHERE      e.quoted_message_id <> 0 ) 
SELECT count(*) 
FROM   quoted;


-- 6. What is the maximum quote chain length?
--     - Your query should return a table with columns (`message_id`, `count`) where message_id is the id of the message which is quoting all the others
--     - Your query should return at most 1 row

WITH recursive quoted AS 
( 
       SELECT id, 
              quoted_message_id, 
              0  AS lenght, 
              id AS last 
       FROM   messages 
       WHERE  quoted_message_id <> 0 
       UNION 
       SELECT     e.id, 
                  e.quoted_message_id, 
                  lenght + 1, 
                  last 
       FROM       messages e 
       INNER JOIN quoted q 
       ON         q.quoted_message_id = e.id 
       WHERE      e.quoted_message_id <> 0 ) 
SELECT   last AS message_id, 
         count(*) 
FROM     quoted 
GROUP BY message_id 
ORDER BY count DESC 
LIMIT 1;
