def visible_area(mountains) -> float:
    landscape = [0] * (max([rights['right'] for rights in mountains]) + 1)
    for i in mountains:
        if i['height'] > landscape[int((i['right']+i['left'])/2)]:
            landscape[int((i['right']+i['left'])/2)] = i['height']

    for i in range(0, len(landscape)):
        for j in range(0, len(landscape)):
            if landscape[j] - abs(i-j) > landscape[i]:
                landscape[i] = landscape[j] - abs(i-j)
    result = 0
    for height in range(0, len(landscape)-1):
        result += (landscape[height] + landscape[height + 1])/2
        if landscape[height] == landscape[height + 1] and landscape[height] != 0:
            result -= 0.25
    return result
