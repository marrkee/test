var numberOfInputs = 0;

function generate() {
    try {
        input = document.getElementById('formatted').value;
        var splitted = input.split("\n");

        data = loadRules();
        var output = "";
        numberOfInputs = 0;

        for (var line = 0, len = splitted.length; line < len; line++) {

            if (splitted[line] != '') {
                output = output + processLine(splitted[line], data);
            }
        }
        document.getElementById('generated').innerHTML = output;
    } catch (ex) {
        document.getElementById('formatted').value = '';
    }
}

function processLine(line, rules) {
    var innerHTML = getInnerHTML(line);
    var type = getType(line, rules);
    var attributes = getAttributes(line, rules);
    return combineTag(type, innerHTML, attributes, rules);

}

function loadRules() {
    object = JSON.parse(rules),
        array = Object.keys(object).map(function(k) {
            return object[k];
        });

    return array;
}

function getType(line, rules) {
    return rules[0][line.split(':')[0].split('[')[0]];
}

function getInnerHTML(line) {
    var splitPoint = line.indexOf(':');
    if (splitPoint > -1) {
        return line.substring(splitPoint + 1);
    }
    return '';
}

function getAttributes(line) {
    var beggining = line.indexOf('[');
    var ending = line.indexOf(']');
    if (beggining > -1 && ending > -1) {
        return line.substring(beggining + 1, ending);
    }
    return '';
}

function combineTag(type, innerHTML, attributes, rules) {
    validateInput(type, innerHTML, attributes, rules);
    if (rules[0]['input'] == type || rules[0]['textarea'] == type) {
        output = "<" + type + ' ' + attributes + 'onChange = "updateField(value,' + numberOfInputs + ')"' + ">";
        numberOfInputs++;
        output = output + innerHTML;
        output = output + "</" + type + ">";
        return output;
    }

    if (rules[0]['summary'] == type) {
        output = "<" + type + ' ' + attributes + ">";
        output = output + innerHTML;
        for (var input = 0; input < numberOfInputs; input++) {
            output += "<p id=" + input + ">$" + input + "</p>";
        }
        output = output + "</" + type + ">";
        return output;
    }
    output = "<" + type + ' ' + attributes + ">";
    output = output + innerHTML;
    output = output + "</" + type + ">";
    return output;
}

function validateInput(type, innerHTML, attributes, rules) {
    if (attributes !== '') {
        attributes.split(', ').forEach(attribute => {
            if (rules[1][type][attribute.substring(0, attribute.indexOf('='))] !== 1) {
                throwErr("invalid input");
            }
        });
    }

    if ((rules[2][type] === 0 && innerHTML !== '') || (rules[2][type] === 1 && innerHTML == '')) {
        throwErr("invalid input");
    }
}

function updateField(value, number) {
    document.getElementById(number).innerHTML = value;
}

function throwErr(mssg) {
    throw new Error(mssg);
}